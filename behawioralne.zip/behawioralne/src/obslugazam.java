public interface obslugazam {
    void setNext(obslugazam next);
    void handle(zamowienie zamowienie);
}
