public class zamowienie {
    private String description;

    public zamowienie(String description) {
        this.description = description;
    }

    public String getDescription() {
        return description;
    }
}
